"""
RepoForge Git Manager

Handles:
- git detection
- checkpoints
- commits
- rollback
"""

from pathlib import Path
import subprocess
from typing import Dict, Any


class GitManager:
    """
    Safe Git operations for RepoForge.
    """


    def __init__(
        self,
        repo_path: str,
    ):

        self.repo_path = Path(
            repo_path
        ).resolve()



    def run_git(
        self,
        *args,
    ) -> Dict[str, Any]:

        try:

            result = subprocess.run(
                [
                    "git",
                    *args,
                ],
                cwd=self.repo_path,
                capture_output=True,
                text=True,
                timeout=60,
            )


            return {

                "success":
                    result.returncode == 0,

                "output":
                    result.stdout.strip(),

                "error":
                    result.stderr.strip(),

            }


        except Exception as error:

            return {

                "success": False,

                "error":
                    str(error),

            }



    def is_git_repo(self):

        result = self.run_git(
            "rev-parse",
            "--is-inside-work-tree",
        )

        return result["success"]



    def status(self):

        return self.run_git(
            "status",
            "--short",
        )



    def add_all(self):

        return self.run_git(
            "add",
            ".",
        )



    def commit(
        self,
        message: str,
    ):

        return self.run_git(
            "commit",
            "-m",
            message,
        )



    def save_state(
        self,
        message: str = "RepoForge AI improvement",
    ):

        if not self.is_git_repo():

            return {

                "success": False,

                "message":
                    "Not a git repository",

            }


        self.add_all()


        result = self.commit(
            message
        )


        return {

            "success":
                result["success"],

            "message":
                result.get(
                    "output"
                )
                or result.get(
                    "error"
                ),

        }



    def rollback(self):

        return self.run_git(
            "reset",
            "--hard",
            "HEAD",
        )