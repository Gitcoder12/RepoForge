"""
RepoForge Validation Engine

Checks whether repository improvements
are safe and working.
"""

from pathlib import Path
import subprocess
import ast
from typing import Dict, Any, List


class RepoValidator:
    """
    Validates repository state after changes.
    """


    def __init__(self, repo_path: str):

        self.repo_path = Path(
            repo_path
        ).resolve()


    def validate(self) -> Dict[str, Any]:
        """
        Run all validation checks.
        """

        return {

            "syntax":
                self.check_python_syntax(),

            "tests":
                self.check_tests(),

            "build":
                self.check_build(),

            "status":
                "completed",

        }


    # ==================================================
    # Python syntax validation
    # ==================================================

    def check_python_syntax(self) -> Dict[str, Any]:

        errors = []


        for file in self.repo_path.rglob(
            "*.py"
        ):

            try:

                source = file.read_text(
                    encoding="utf-8",
                    errors="ignore",
                )

                ast.parse(
                    source
                )


            except SyntaxError as error:

                errors.append({

                    "file":
                        str(
                            file.relative_to(
                                self.repo_path
                            )
                        ),

                    "line":
                        error.lineno,

                    "message":
                        error.msg,

                })


        return {

            "passed":
                len(errors) == 0,

            "errors":
                errors,

        }


    # ==================================================
    # Test detection
    # ==================================================

    def check_tests(self) -> Dict[str, Any]:

        test_files: List[str] = []


        for file in self.repo_path.rglob("*"):

            if not file.is_file():
                continue


            name = file.name.lower()


            if (
                name.startswith("test")
                or
                ".test." in name
                or
                "_test." in name
            ):

                test_files.append(
                    str(
                        file.relative_to(
                            self.repo_path
                        )
                    )
                )


        return {

            "available":
                len(test_files) > 0,

            "files":
                test_files,

        }


    # ==================================================
    # Build validation
    # ==================================================

    def check_build(self) -> Dict[str, Any]:

        commands = []


        if (
            self.repo_path /
            "package.json"
        ).exists():

            commands.append(
                [
                    "npm",
                    "test",
                ]
            )


        if (
            self.repo_path /
            "pyproject.toml"
        ).exists() or (
            self.repo_path /
            "requirements.txt"
        ).exists():

            commands.append(
                [
                    "pytest",
                ]
            )


        results = []


        for command in commands:

            try:

                process = subprocess.run(
                    command,
                    cwd=self.repo_path,
                    capture_output=True,
                    text=True,
                    timeout=60,
                )


                results.append({

                    "command":
                        " ".join(command),

                    "success":
                        process.returncode == 0,

                    "output":
                        process.stdout[-500:],

                })


            except Exception as error:

                results.append({

                    "command":
                        " ".join(command),

                    "success":
                        False,

                    "error":
                        str(error),

                })


        return results