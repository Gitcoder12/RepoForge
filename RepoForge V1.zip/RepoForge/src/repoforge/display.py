"""
RepoForge Display Engine

Clean CLI output formatter.
"""


from typing import Dict, Any



class Display:


    @staticmethod
    def header(
        text: str
    ):

        print()
        print("=" * 60)
        print(text)
        print("=" * 60)



    @classmethod
    def forge_result(
        cls,
        result: Dict[str, Any],
    ):


        cls.header(
            "🔥 RepoForge Complete"
        )


        print(
            f"\n🎯 Task:\n{result.get('prompt')}"
        )


        stages = result.get(
            "stages",
            {}
        )


        # Scan

        cls.header(
            "🔍 Repository Analysis"
        )


        scan = stages.get(
            "scan",
            {}
        )


        stats = scan.get(
            "statistics",
            {}
        )


        print(
            f"Project: {scan.get('project')}"
        )

        print(
            f"Files scanned: {stats.get('files',0)}"
        )

        print(
            f"Lines scanned: {stats.get('lines',0)}"
        )


        languages = scan.get(
            "languages",
            {}
        )


        if languages:

            print(
                "\nLanguages:"
            )

            for lang,data in languages.items():

                print(
                    f"  • {lang}: {data['percentage']}%"
                )



        # AI

        cls.header(
            "🤖 AI Engineer"
        )


        ai = stages.get(
            "ai",
            {}
        )


        print(
            ai.get(
                "summary",
                {}
            ).get(
                "message",
                ""
            )
        )


        for item in ai.get(
            "successful",
            []
        ):

            print(
                f"\nModel: {item.get('model')}"
            )

            print(
                f"Provider: {item.get('provider')}"
            )


        for item in ai.get(
            "failed",
            []
        ):

            print(
                "\n❌ AI FAILED"
            )

            print(
                item.get(
                    "response"
                )
            )

            if item.get(
                "traceback"
            ):

                print(
                    item["traceback"]
                )



        # Forge

        cls.header(
            "🔨 Forge Actions"
        )


        forge = stages.get(
            "forge",
            []
        )


        if not forge:

            print(
                "No actions executed."
            )


        for item in forge:

            print(
                f"Actions detected: {item.get('total_actions',0)}"
            )

            print(
                f"Completed: {item.get('completed',0)}"
            )


            for change in item.get(
                "results",
                []
            ):

                print(
                    f"  ✅ {change.get('file')}"
                )



        # Validation

        cls.header(
            "🧪 Validation"
        )


        validation = stages.get(
            "validation",
            {}
        )


        syntax = validation.get(
            "syntax",
            {}
        )


        print(
            "Syntax: ✅ Passed"
            if syntax.get("passed")
            else
            "Syntax: ❌ Failed"
        )



        # Git

        cls.header(
            "📦 Git"
        )


        git = stages.get(
            "git",
            {}
        )


        if git.get(
            "success"
        ):

            print(
                "Git: ✅ Saved"
            )

        else:

            print(
                "Git: ⚠ Not saved"
            )

            print(
                git.get(
                    "message",
                    ""
                )
            )


        print(
            "\n🚀 RepoForge finished successfully\n"
        )