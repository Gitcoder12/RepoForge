"""
RepoForge CLI

Main command interface.
"""

import typer


app = typer.Typer(
    help="🚀 RepoForge - AI Repository Engineering Platform"
)



@app.command()
def hello():

    """
    Check RepoForge status.
    """

    typer.echo(
        "🚀 RepoForge is alive!"
    )



@app.command()
def doctor():

    """
    Run system diagnostics.
    """

    from repoforge.commands.doctor import run_doctor

    run_doctor()



@app.command()
def chat(
    prompt: str,
    model: str = typer.Option(
        None,
        "--model",
        "-m",
        help="Choose AI model.",
    ),
):

    """
    Chat with AI models.
    """

    from repoforge.commands.chat import run_chat

    run_chat(
        prompt,
        model,
    )



@app.command()
def providers():

    """
    List AI providers.
    """

    from repoforge.commands.providers import run_providers

    run_providers()



@app.command()
def models():

    """
    List AI models.
    """

    from repoforge.commands.models import run_models

    run_models()



@app.command()
def use(
    provider: str,
):

    """
    Select active provider.
    """

    from repoforge.commands.use import run_use

    run_use(
        provider
    )



@app.command()
def version():

    """
    Show RepoForge version.
    """

    typer.echo(
        "RepoForge v0.1.0"
    )



@app.command()
def scan(
    path: str = typer.Argument(
        ".",
        help="Project path",
    ),
):

    """
    Scan repository.
    """

    from repoforge.commands.scan import run_scan

    run_scan(
        path
    )



@app.command()
def forge(
    path: str = typer.Argument(
        ".",
        help="Repository path",
    ),

    prompt: str = typer.Argument(
        ...,
        help="Improvement instruction",
    ),
):

    """
    Analyze and improve a repository.
    """

    from repoforge.workflow_engine import WorkflowEngine
    from repoforge.display import Display


    typer.echo("")

    typer.echo(
        "=" * 60
    )

    typer.echo(
        "🔥 RepoForge Forge Engine"
    )

    typer.echo(
        "=" * 60
    )


    typer.echo(
        f"📂 Repository: {path}"
    )


    typer.echo(
        f"🎯 Task: {prompt}"
    )


    engine = WorkflowEngine(
        path
    )


    result = engine.execute(
        prompt
    )


    Display.forge_result(
        result
    )



if __name__ == "__main__":

    app()