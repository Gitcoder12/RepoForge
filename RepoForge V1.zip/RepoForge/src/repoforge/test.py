import sys

def main():
    if len(sys.argv) > 1 and sys.argv[1] == "hello":
        print("RepoForge is alive!")
    else:
        print("Usage: python test.py hello")

if __name__ == "__main__":
    main()