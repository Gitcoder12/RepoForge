"""
RepoForge AI Strategy Engine

Decides the best workflow
for repository improvement.
"""

from dataclasses import dataclass
from typing import List, Dict, Any



@dataclass
class ExecutionPlan:
    """
    Strategy produced before execution.
    """

    mode: str

    roles: List[str]

    discussion_rounds: int

    review: bool

    parallel: bool



class AIStrategist:
    """
    Decides HOW RepoForge solves a problem.
    """


    def create_plan(
        self,
        prompt: str,
        context: Dict[str, Any] | None = None,
    ) -> ExecutionPlan:


        text = prompt.lower()


        # ---------------------------------------
        # Repository improvement mode
        # ---------------------------------------

        if context:

            roles = []


            issues = context.get(
                "issues",
                []
            )

            security = context.get(
                "security",
                []
            )


            if security:

                roles.append(
                    "security"
                )


            if issues:

                roles.append(
                    "analysis"
                )


            roles.extend(
                [
                    "testing",
                    "refactoring",
                    "documentation",
                ]
            )


            return ExecutionPlan(

                mode="repository_improvement",

                roles=list(
                    dict.fromkeys(
                        roles
                    )
                ),

                discussion_rounds=1,

                review=True,

                parallel=True,

            )


        # ---------------------------------------
        # Research
        # ---------------------------------------

        if any(
            word in text
            for word in
            [
                "research",
                "paper",
                "study",
                "analysis",
            ]
        ):

            return ExecutionPlan(

                mode="research",

                roles=[
                    "research",
                    "review",
                    "documentation",
                ],

                discussion_rounds=1,

                review=True,

                parallel=True,

            )


        # ---------------------------------------
        # Coding task
        # ---------------------------------------

        if any(
            word in text
            for word in
            [
                "code",
                "python",
                "java",
                "api",
                "algorithm",
            ]
        ):

            return ExecutionPlan(

                mode="coding",

                roles=[
                    "coding",
                    "testing",
                ],

                discussion_rounds=0,

                review=True,

                parallel=False,

            )


        # ---------------------------------------
        # General
        # ---------------------------------------

        return ExecutionPlan(

            mode="general",

            roles=[
                "general",
            ],

            discussion_rounds=0,

            review=False,

            parallel=False,

        )