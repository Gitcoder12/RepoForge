"""
RepoForge Action Runner

Connects:
AI Response
      ↓
ActionParser
      ↓
ForgeEngine
      ↓
File Changes
"""

from typing import Dict, Any, List

from repoforge.forge_engine import ForgeEngine
from repoforge.action_parser import ActionParser



class ActionRunner:
    """
    Executes AI generated repository actions safely.
    """



    def __init__(
        self,
        repo_path: str,
    ):

        self.forge = ForgeEngine(
            repo_path
        )

        self.parser = ActionParser()



    def run(
        self,
        response: str,
    ) -> Dict[str, Any]:

        actions = self.parser.parse(
            response
        )


        results = []


        for action in actions:

            try:

                result = (
                    self.forge
                    .apply_action(
                        action
                    )
                )


                results.append(
                    result
                )


            except Exception as error:

                results.append(
                    {
                        "success": False,
                        "error": str(error),
                        "action": action,
                    }
                )


        return {

            "total_actions":
                len(actions),

            "completed":
                len(
                    [
                        r for r in results
                        if r.get("success")
                    ]
                ),

            "results":
                results,

        }