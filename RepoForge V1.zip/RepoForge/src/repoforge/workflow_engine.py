"""
RepoForge Workflow Engine

Pipeline:

Scanner
   ↓
AI Orchestrator
   ↓
Action Runner
   ↓
Forge Engine
   ↓
Validator
   ↓
Git Checkpoint
"""

from typing import Dict, Any


from repoforge.validator import RepoValidator
from repoforge.git_manager import GitManager
from repoforge.orchestrator import AIOrchestrator
from repoforge.action_runner import ActionRunner
from repoforge.scanner import RepoScanner



class WorkflowEngine:
    """
    Complete RepoForge autonomous workflow.
    """


    def __init__(
        self,
        repo_path: str,
    ):

        self.repo_path = repo_path


        self.scanner = RepoScanner(
            repo_path
        )


        self.ai = AIOrchestrator()


        self.runner = ActionRunner(
            repo_path
        )


        self.validator = RepoValidator(
            repo_path
        )


        self.git = GitManager(
            repo_path
        )



    def analyze(self):

        return self.scanner.analyze()



    def execute(
        self,
        prompt: str,
    ) -> Dict[str, Any]:


        result = {

            "prompt":
                prompt,

            "stages":
                {}

        }



        # ======================================
        # 1. Scan repository
        # ======================================

        scan = self.scanner.analyze()


        result["stages"]["scan"] = scan



        # ======================================
        # 2. AI analysis + solution
        # ======================================

        ai_result = self.ai.execute(
            prompt,
            context=scan,
        )


        result["stages"]["ai"] = ai_result



        # ======================================
        # 3. Apply Forge actions
        # ======================================

        forge_results = []


        response = str(
            ai_result
        )


        action_result = self.runner.run(
            response
        )


        forge_results.append(
            action_result
        )


        result["stages"]["forge"] = forge_results



        # ======================================
        # 4. Validate repository
        # ======================================

        validation = (
            self.validator.validate()
        )


        result["stages"]["validation"] = validation



        # ======================================
        # 5. Git checkpoint
        # ======================================

        syntax_ok = (
            validation
            .get(
                "syntax",
                {}
            )
            .get(
                "passed",
                False
            )
        )


        if syntax_ok:

            git_result = self.git.save_state(
                "RepoForge AI improvement"
            )


        else:

            git_result = {

                "success":
                    False,

                "message":
                    "Validation failed. Changes not committed."

            }



        result["stages"]["git"] = git_result



        return result