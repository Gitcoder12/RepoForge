"""
RepoForge Action Parser

Extracts AI generated Forge actions safely.
"""

import json
import re
from typing import List, Dict, Any


class ActionParser:
    """
    Converts AI responses into Forge actions.
    """

    def parse(
        self,
        response: str,
    ) -> List[Dict[str, Any]]:

        actions = []

        blocks = self.extract_json(
            response
        )

        for block in blocks:

            try:

                data = json.loads(
                    block
                )

                items = []

                if isinstance(data, list):

                    items = data


                elif isinstance(data, dict):

                    items = [data]


                for item in items:

                    if self.validate_action(item):

                        actions.append(
                            item
                        )


            except json.JSONDecodeError:

                continue


        return self.remove_duplicates(
            actions
        )



    def extract_json(
        self,
        text: str,
    ) -> List[str]:

        blocks = []


        # Markdown JSON blocks

        matches = re.findall(
            r"```(?:json)?\s*(.*?)```",
            text,
            re.DOTALL | re.IGNORECASE,
        )


        for match in matches:

            blocks.append(
                match.strip()
            )


        # Raw array extraction

        start = text.find("[")

        end = text.rfind("]")


        if (
            start != -1
            and
            end != -1
            and
            end > start
        ):

            blocks.append(
                text[start:end + 1]
            )


        # Raw object extraction

        start = text.find("{")

        end = text.rfind("}")


        if (
            start != -1
            and
            end != -1
            and
            end > start
        ):

            blocks.append(
                text[start:end + 1]
            )


        return blocks



    def validate_action(
        self,
        action: Dict[str, Any],
    ) -> bool:


        if not isinstance(
            action,
            dict
        ):

            return False


        required = [
            "type",
            "file",
            "content",
        ]


        for key in required:

            if key not in action:

                return False


        if not isinstance(
            action["file"],
            str
        ):

            return False


        if not isinstance(
            action["content"],
            str
        ):

            return False


        return True



    def remove_duplicates(
        self,
        actions: List[Dict[str, Any]],
    ) -> List[Dict[str, Any]]:


        seen = set()

        result = []


        for action in actions:

            key = (
                action["type"],
                action["file"],
            )


            if key not in seen:

                seen.add(
                    key
                )

                result.append(
                    action
                )


        return result