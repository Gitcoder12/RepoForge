"""
RepoForge Repository Scanner V2

Analyzes repositories:
- structure
- languages
- statistics
- TODOs
- security issues
- quality issues
"""

from pathlib import Path
from typing import Dict, Any
from collections import Counter
import os
import re



class RepoScanner:


    IGNORE_DIRS = {

        ".git",
        ".idea",
        ".vscode",
        "__pycache__",
        "node_modules",
        "venv",
        ".venv",
        "dist",
        "build",
        "target",
        "coverage",

    }



    LANGUAGE_MAP = {

        ".py": "Python",
        ".js": "JavaScript",
        ".jsx": "React",
        ".ts": "TypeScript",
        ".tsx": "React TypeScript",
        ".java": "Java",
        ".cpp": "C++",
        ".c": "C",
        ".go": "Go",
        ".rs": "Rust",
        ".rb": "Ruby",
        ".php": "PHP",
        ".cs": "C#",
        ".swift": "Swift",
        ".kt": "Kotlin",
        ".html": "HTML",
        ".css": "CSS",
        ".md": "Markdown",

    }



    SECRET_PATTERNS = [

        r"api[_-]?key\s*=",
        r"password\s*=",
        r"secret\s*=",
        r"token\s*=",
        r"private[_-]?key",

    ]



    def __init__(
        self,
        repo_path: str,
    ):

        self.repo_path = Path(
            repo_path
        ).resolve()



    def analyze(self):

        return {

            "project":
                self.repo_path.name,


            "structure":
                self.get_structure(),


            "languages":
                self.detect_languages(),


            "statistics":
                self.get_stats(),


            "todos":
                self.find_todos(),


            "security":
                self.security_scan(),


            "issues":
                self.detect_issues(),

        }



    def iter_files(self):


        if not self.repo_path.exists():

            return



        for root, dirs, files in os.walk(
            self.repo_path
        ):


            dirs[:] = [

                d for d in dirs

                if d not in self.IGNORE_DIRS

            ]



            for filename in files:


                path = Path(root) / filename


                # skip hidden files only

                if filename.startswith("."):

                    continue



                # skip huge binaries

                try:

                    if path.stat().st_size > 2_000_000:

                        continue

                except Exception:

                    continue



                yield path



    def get_structure(self):

        tree = {}


        for file in self.iter_files():


            relative = file.relative_to(
                self.repo_path
            )


            current = tree


            for part in relative.parts[:-1]:

                current = current.setdefault(
                    part,
                    {}
                )


            current[
                relative.parts[-1]
            ] = True



        return tree



    def detect_languages(self):

        counter = Counter()


        for file in self.iter_files():


            language = self.LANGUAGE_MAP.get(
                file.suffix.lower()
            )


            if language:

                counter[language] += 1



        total = sum(counter.values()) or 1



        return {

            lang: {

                "files":
                    count,


                "percentage":
                    round(
                        count / total * 100,
                        2
                    )

            }

            for lang, count in counter.items()

        }



    def get_stats(self):

        files = list(
            self.iter_files()
        )


        lines = 0

        extensions = Counter()



        for file in files:


            extensions[
                file.suffix.lower()
                or "none"
            ] += 1



            try:

                with open(
                    file,
                    encoding="utf-8",
                    errors="ignore",
                ) as f:


                    lines += sum(
                        1 for _ in f
                    )


            except Exception:

                pass



        return {

            "files":
                len(files),


            "lines":
                lines,


            "directories":
                len(
                    {
                        f.parent
                        for f in files
                    }
                ),


            "extensions":
                dict(
                    extensions
                )

        }



    def find_todos(self):

        results = []


        for file in self.iter_files():


            try:

                text = file.read_text(
                    encoding="utf-8",
                    errors="ignore"
                )


                for number, line in enumerate(
                    text.splitlines(),
                    1
                ):


                    if any(

                        key in line.upper()

                        for key in [

                            "TODO",
                            "FIXME",
                            "BUG",
                            "HACK"

                        ]

                    ):


                        results.append({

                            "file":
                                str(
                                    file.relative_to(
                                        self.repo_path
                                    )
                                ),


                            "line":
                                number,


                            "text":
                                line.strip()

                        })


            except Exception:

                pass



        return results



    def security_scan(self):

        findings = []


        for file in self.iter_files():


            try:

                text = file.read_text(
                    encoding="utf-8",
                    errors="ignore"
                )


                for pattern in self.SECRET_PATTERNS:


                    if re.search(
                        pattern,
                        text,
                        re.IGNORECASE
                    ):


                        findings.append({

                            "file":
                                str(
                                    file.relative_to(
                                        self.repo_path
                                    )
                                ),


                            "issue":
                                "Possible secret detected"

                        })


                        break



            except Exception:

                pass



        return findings



    def detect_issues(self):

        issues = []



        if not (
            self.repo_path / "README.md"
        ).exists():


            issues.append({

                "severity":
                    "high",

                "type":
                    "documentation",

                "message":
                    "Missing README.md"

            })



        if not (
            self.repo_path / "tests"
        ).exists():


            issues.append({

                "severity":
                    "medium",

                "type":
                    "quality",

                "message":
                    "No test directory"

            })



        return issues