"""
RepoForge AI Fix Reporter V2

Generates human readable improvement reports.
"""


from rich.console import Console
from rich.panel import Panel
from rich.table import Table



console = Console()



class FixReporter:
    """
    Displays AI engineering summary.
    """



    def generate(
        self,
        forge_result: dict,
    ):


        report = []


        forge = forge_result.get(
            "stages",
            {}
        ).get(
            "forge",
            []
        )


        for item in forge:


            if not isinstance(
                item,
                dict
            ):

                continue


            actions = item.get(
                "actions",
                []
            )


            for action in actions:

                report.append(
                    {

                        "type":
                            action.get(
                                "type",
                                ""
                            ),

                        "file":
                            action.get(
                                "file",
                                ""
                            ),

                        "status":
                            "completed"

                    }
                )


        return report



    def display(
        self,
        report,
    ):


        console.print(
            Panel(
                "🤖 AI Engineer Report",
                expand=False
            )
        )


        table = Table()


        table.add_column(
            "Action"
        )

        table.add_column(
            "File"
        )

        table.add_column(
            "Status"
        )


        for item in report:


            table.add_row(

                item["type"],

                item["file"],

                "✅ " + item["status"]

            )


        console.print(
            table
        )