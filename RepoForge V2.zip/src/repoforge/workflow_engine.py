"""
RepoForge Workflow Engine V2

Pipeline:

Scanner
   ↓
Intelligence Engine
   ↓
AI Orchestrator
   ↓
Action Runner
   ↓
Validator
   ↓
Git Checkpoint
"""


from typing import Dict, Any


from repoforge.validator import RepoValidator
from repoforge.git_manager import GitManager
from repoforge.orchestrator import AIOrchestrator
from repoforge.action_runner import ActionRunner
from repoforge.scanner import RepoScanner
from repoforge.intelligence.intelligence_engine import IntelligenceEngine



class WorkflowEngine:
    """
    Complete RepoForge autonomous workflow.
    """



    def __init__(
        self,
        repo_path: str,
    ):

        self.repo_path = repo_path


        self.scanner = RepoScanner(
            repo_path
        )


        self.intelligence = IntelligenceEngine(
            repo_path
        )


        self.ai = AIOrchestrator()


        self.runner = ActionRunner(
            repo_path
        )


        self.validator = RepoValidator(
            repo_path
        )


        self.git = GitManager(
            repo_path
        )



    def analyze(self):

        scan = self.scanner.analyze()


        return {

            "scan":
                scan,

            "intelligence":
                self.intelligence.analyze(
                    scan
                )

        }



    def execute(
        self,
        prompt: str,
    ) -> Dict[str, Any]:


        result = {

            "prompt":
                prompt,

            "stages":
                {}

        }



        # ==============================
        # 1. Repository Scan
        # ==============================

        scan = self.scanner.analyze()


        result["stages"]["scan"] = scan



        # ==============================
        # 2. Intelligence
        # ==============================

        intelligence = (
            self.intelligence
            .analyze(
                scan
            )
        )


        result["stages"]["intelligence"] = intelligence



        # ==============================
        # 3. AI Engineer
        # ==============================

        ai_result = self.ai.execute(

            prompt,

            context={

                "scan":
                    scan,

                "intelligence":
                    intelligence,

            }

        )


        result["stages"]["ai"] = ai_result



        # ==============================
        # 4. Forge Actions
        # ==============================

        response = ""


        if isinstance(
            ai_result,
            dict
        ):

            response = ai_result.get(
                "response",
                ""
            )

        else:

            response = str(
                ai_result
            )



        action_result = self.runner.run(
            response
        )


        result["stages"]["forge"] = [

            action_result

        ]



        # ==============================
        # 5. Validation
        # ==============================

        validation = (
            self.validator
            .validate()
        )


        result["stages"]["validation"] = validation



        # ==============================
        # 6. Git Checkpoint
        # ==============================

        syntax_ok = (

            validation
            .get(
                "syntax",
                {}
            )
            .get(
                "passed",
                False
            )

        )


        if syntax_ok:

            git_result = self.git.save_state(

                "RepoForge AI improvement"

            )


        else:

            git_result = {

                "success":
                    False,

                "message":
                    "Validation failed. Changes not committed."

            }



        result["stages"]["git"] = git_result



        return result