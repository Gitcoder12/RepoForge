"""
RepoForge Display V2

Clean terminal dashboard.
"""


from rich.console import Console
from rich.panel import Panel
from rich.table import Table



console = Console()



class Display:
    """
    RepoForge terminal UI.
    """



    @staticmethod
    def header():

        console.print(
            Panel(
                "🔥 RepoForge V2\nAutonomous AI Repository Engineer",
                expand=False,
            )
        )



    @staticmethod
    def forge_result(
        result,
    ):


        Display.header()


        console.print(
            "\n🎯 Task"
        )

        console.print(
            result.get(
                "prompt",
                ""
            )
        )



        stages = result.get(
            "stages",
            {}
        )



        Display.repository_report(
            stages.get(
                "scan",
                {}
            )
        )


        Display.intelligence_report(
            stages.get(
                "intelligence",
                {}
            )
        )


        Display.forge_report(
            stages.get(
                "forge",
                []
            )
        )


        Display.validation_report(
            stages.get(
                "validation",
                {}
            )
        )


        Display.git_report(
            stages.get(
                "git",
                {}
            )
        )



        console.print(
            "\n🚀 RepoForge finished successfully"
        )



    @staticmethod
    def repository_report(
        scan,
    ):


        table = Table(
            title="🔍 Repository Analysis"
        )


        table.add_column(
            "Metric"
        )


        table.add_column(
            "Value"
        )


        stats = scan.get(
            "statistics",
            {}
        )


        table.add_row(
            "Files",
            str(
                stats.get(
                    "files",
                    0
                )
            )
        )


        table.add_row(
            "Lines",
            str(
                stats.get(
                    "lines",
                    0
                )
            )
        )


        languages = scan.get(
            "languages",
            {}
        )


        table.add_row(
            "Languages",
            ", ".join(
                languages.keys()
            )
            if languages
            else "Unknown"
        )


        console.print(
            table
        )



    @staticmethod
    def intelligence_report(
        intelligence,
    ):


        if not intelligence:

            return


        console.print(
            "\n🧠 Repository Intelligence"
        )


        quality = intelligence.get(
            "quality",
            {}
        )


        table = Table(
            title="Quality Score"
        )


        table.add_column(
            "Score"
        )


        table.add_column(
            "Grade"
        )


        table.add_row(

            f"{quality.get('score',0)}/100",

            quality.get(
                "grade",
                "N/A"
            )

        )


        console.print(
            table
        )



        recommendations = intelligence.get(
            "recommendations",
            []
        )


        if recommendations:


            rec = Table(
                title="🔥 Recommended Fixes"
            )


            rec.add_column(
                "Priority"
            )


            rec.add_column(
                "Fix"
            )


            rec.add_column(
                "Impact"
            )


            rec.add_column(
                "Difficulty"
            )



            for item in recommendations[:5]:


                rec.add_row(

                    str(
                        item.get(
                            "priority_score",
                            0
                        )
                    ),


                    item.get(
                        "title",
                        ""
                    ),


                    item.get(
                        "impact",
                        ""
                    ),


                    item.get(
                        "difficulty",
                        ""
                    )

                )


            console.print(
                rec
            )



    @staticmethod
    def forge_report(
        forge,
    ):


        console.print(
            "\n🔨 Forge Actions"
        )


        if not forge:

            console.print(
                "No actions generated"
            )

            return



        for item in forge:


            if isinstance(
                item,
                dict
            ):


                table = Table()


                table.add_column(
                    "Metric"
                )


                table.add_column(
                    "Value"
                )


                table.add_row(
                    "Changes detected",
                    str(
                        item.get(
                            "total_actions",
                            0
                        )
                    )
                )


                table.add_row(
                    "Completed",
                    str(
                        item.get(
                            "completed",
                            0
                        )
                    )
                )


                console.print(
                    table
                )



    @staticmethod
    def validation_report(
        validation,
    ):


        console.print(
            "\n🧪 Validation"
        )


        syntax = validation.get(
            "syntax",
            {}
        )


        if syntax.get(
            "passed",
            False
        ):


            console.print(
                "Syntax: ✅ Passed"
            )


        else:


            console.print(
                "Syntax: ❌ Failed"
            )



    @staticmethod
    def git_report(
        git,
    ):


        console.print(
            "\n📦 Git"
        )


        console.print(
            git.get(
                "message",
                "No checkpoint"
            )
        )