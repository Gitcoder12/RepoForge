"""
RepoForge Action Runner

Parses and executes AI generated actions.
"""

from pathlib import Path

from repoforge.action_parser import ActionParser



class ActionRunner:
    """
    Executes Forge actions safely.
    """


    def __init__(
        self,
        repo_path: str,
    ):

        self.repo_path = Path(
            repo_path
        )

        self.parser = ActionParser()



    def run(
        self,
        response,
    ):


        actions = self.parser.parse(
            response
        )


        completed = []


        for action in actions:

            if self.execute(action):

                completed.append(
                    action
                )


        return {

            "total_actions":
                len(actions),

            "completed":
                len(completed),

            "actions":
                completed,

        }



    def execute(
        self,
        action,
    ):


        file_path = (
            self.repo_path
            /
            action["file"]
        )


        if action["type"] in [
            "create",
            "modify",
        ]:


            file_path.parent.mkdir(
                parents=True,
                exist_ok=True,
            )


            file_path.write_text(
                action["content"],
                encoding="utf-8",
            )


            return True



        if action["type"] == "delete":


            if file_path.exists():

                file_path.unlink()


            return True



        return False