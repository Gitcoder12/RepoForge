"""
RepoForge AI Executor

Executes AI tasks safely.
"""

from concurrent.futures import (
    ThreadPoolExecutor,
    as_completed,
)

import traceback


from repoforge.models import (
    DEFAULT_MODEL,
    MODELS,
)


from repoforge.providers.factory import ProviderFactory
from repoforge.providers.spare import SpareModel



class AIExecutor:
    """
    Executes RepoForge AI jobs.
    """


    def __init__(self):

        self.factory = ProviderFactory()

        # Secondary AI if primary provider fails
        self.spare_model = SpareModel()



    def _build_prompt(
        self,
        prompt: str,
        context: dict,
    ) -> str:

        return f"""
You are RepoForge AI Engineer.

Analyze the repository and generate safe improvements.

Repository Context:

{context}


Task:

{prompt}


Return:

## Analysis

Explain:
- Problem
- Root cause
- Impact


## Solution Plan

Explain:
- Changes required
- Why they improve the repository


## Forge Actions

Return ONLY valid JSON array:

[
  {{
    "type": "modify",
    "file": "relative/path/file.py",
    "content": "complete file content"
  }}
]


Rules:

- Use relative paths only
- Never use absolute paths
- Preserve existing functionality
- Include complete file content
- If no changes are needed return []
"""



    def _execute_task(
        self,
        job: dict,
    ):


        task_name = job.get(
            "task",
            "unknown",
        )


        provider_name = job.get(
            "provider",
            "openrouter",
        )


        model_name = job.get(
            "model",
            DEFAULT_MODEL,
        )


        prompt = job.get(
            "prompt",
            "",
        )


        context = job.get(
            "context",
            {},
        )



        try:

            provider = self.factory.create(
                provider_name
            )


            model_id = MODELS.get(
                model_name,
                MODELS[DEFAULT_MODEL],
            )


            response = provider.generate(
                self._build_prompt(
                    prompt,
                    context,
                ),
                model=model_id,
            )


            return {

                "task":
                    task_name,

                "provider":
                    provider_name,

                "model":
                    model_name,

                "success":
                    True,

                "response":
                    response,

            }



        except Exception as error:


            try:

                response = self.spare_model.generate(
                    self._build_prompt(
                        prompt,
                        context,
                    )
                )


                return {

                    "task":
                        task_name,

                    "provider":
                        "spare_model",

                    "model":
                        "spare",

                    "success":
                        True,

                    "response":
                        response,

                    "fallback_reason":
                        str(error),

                }



            except Exception as spare_error:


                return {

                    "task":
                        task_name,

                    "provider":
                        "none",

                    "model":
                        "failed",

                    "success":
                        False,

                    "response":
                        str(spare_error),

                    "traceback":
                        traceback.format_exc(),

                }





    def execute(
        self,
        jobs,
    ):


        if not jobs:

            return []



        results = []


        workers = min(
            len(jobs),
            5,
        )



        with ThreadPoolExecutor(
            max_workers=workers
        ) as executor:


            futures = [

                executor.submit(
                    self._execute_task,
                    job,
                )

                for job in jobs

            ]



            for future in as_completed(
                futures
            ):

                results.append(
                    future.result()
                )


        return results