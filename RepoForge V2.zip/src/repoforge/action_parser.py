"""
RepoForge Action Parser V2

Extracts and validates AI generated Forge actions.
"""


import json
import re

from typing import List, Dict, Any



class ActionParser:
    """
    Converts AI responses into safe Forge actions.
    """



    def parse(
        self,
        response: str,
    ) -> List[Dict[str, Any]]:


        actions = []


        for block in self.extract_json(response):


            try:

                data = json.loads(
                    block
                )


                if isinstance(
                    data,
                    list
                ):


                    for item in data:

                        if self.validate_action(
                            item
                        ):

                            actions.append(
                                item
                            )


                elif isinstance(
                    data,
                    dict
                ):


                    if self.validate_action(
                        data
                    ):

                        actions.append(
                            data
                        )


            except Exception:

                pass



        return actions



    def extract_json(
        self,
        text: str,
    ) -> List[str]:


        if not isinstance(
            text,
            str
        ):

            return []



        blocks = []



        # ```json blocks

        matches = re.findall(

            r"```(?:json)?\s*(.*?)```",

            text,

            re.DOTALL | re.IGNORECASE

        )


        blocks.extend(matches)



        # raw arrays

        start = text.find("[")

        end = text.rfind("]")


        if start != -1 and end != -1:


            blocks.append(

                text[start:end+1]

            )



        return [

            x.strip()

            for x in blocks

            if x.strip()

        ]



    def validate_action(
        self,
        action: Dict[str, Any],
    ) -> bool:


        if not isinstance(
            action,
            dict
        ):

            return False



        required = [

            "type",

            "file",

            "content"

        ]



        if not all(

            key in action

            for key in required

        ):

            return False



        if action["type"] not in [

            "create",

            "modify",

            "delete"

        ]:

            return False



        if not isinstance(
            action["file"],
            str
        ):

            return False



        if not isinstance(
            action["content"],
            str
        ):

            return False



        if ".." in action["file"]:

            return False



        return True