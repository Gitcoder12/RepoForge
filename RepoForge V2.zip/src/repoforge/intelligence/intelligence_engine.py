"""
RepoForge Intelligence Engine V2

Combines repository understanding systems.
"""


from typing import Dict, Any


from repoforge.intelligence.quality_score import QualityScore
from repoforge.intelligence.repository_map import RepositoryMap
from repoforge.intelligence.dependency_graph import DependencyGraph
from repoforge.intelligence.recommendations import RecommendationEngine
from repoforge.intelligence.score_engine import ScoreEngine



class IntelligenceEngine:
    """
    Complete repository intelligence layer.
    """



    def __init__(
        self,
        repo_path: str,
    ):

        self.repo_path = repo_path


        self.quality = QualityScore()


        self.score_engine = ScoreEngine()


        self.repository_map = RepositoryMap(
            repo_path
        )


        self.dependencies = DependencyGraph(
            repo_path
        )


        self.recommendations = RecommendationEngine()



    def analyze(
        self,
        scan: Dict[str, Any] | None = None,
    ) -> Dict[str, Any]:


        scan = scan or {}



        intelligence = {


            "repository":

                self.repo_path,



            "quality":

                self.quality.calculate(
                    scan
                ),



            "score":

                self.score_engine.calculate(
                    scan
                ),



            "architecture":

                self.repository_map.build(),



            "dependencies":

                self.dependencies.build(),



            "status":

                "ready",

        }



        intelligence["recommendations"] = (

            self.recommendations.generate(
                intelligence
            )

        )



        return intelligence