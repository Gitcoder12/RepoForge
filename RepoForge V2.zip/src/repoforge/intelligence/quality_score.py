"""
RepoForge Quality Score Engine V2

Calculates repository health score.
"""


from typing import Dict, Any



class QualityScore:

    """
    Repository quality evaluator.
    """



    def calculate(
        self,
        scan: Dict[str, Any],
    ) -> Dict[str, Any]:


        score = 100

        improvements = []


        stats = scan.get(
            "statistics",
            {}
        )


        issues = scan.get(
            "issues",
            []
        )


        files = stats.get(
            "files",
            0
        )


        lines = stats.get(
            "lines",
            0
        )



        # README

        if not any(
            i.get("type") == "documentation"
            for i in issues
        ):

            pass

        else:

            score -= 15

            improvements.append(
                "Add complete README documentation"
            )



        # Tests

        if not any(
            "test" in str(i).lower()
            for i in issues
        ):

            pass

        else:

            score -= 15

            improvements.append(
                "Add automated tests"
            )



        # Size

        if files > 500:

            improvements.append(
                "Review large repository structure"
            )


        if lines > 50000:

            improvements.append(
                "Improve code modularity"
            )



        score = max(
            0,
            score
        )


        return {

            "score":
                score,

            "grade":
                self.grade(score),

            "improvements":
                improvements,

        }



    def grade(
        self,
        score,
    ):


        if score >= 90:

            return "A"


        if score >= 75:

            return "B"


        if score >= 60:

            return "C"


        if score >= 40:

            return "D"


        return "F"