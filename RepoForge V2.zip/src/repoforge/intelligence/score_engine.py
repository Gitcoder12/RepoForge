"""
RepoForge Score Engine V2

Calculates repository health score.
"""


from typing import Dict, Any



class ScoreEngine:
    """
    Repository quality scoring system.
    """



    def calculate(
        self,
        scan: Dict[str, Any],
    ) -> Dict[str, Any]:


        score = 100


        breakdown = {

            "code_quality": 100,

            "documentation": 100,

            "testing": 100,

            "security": 100,

        }



        issues = scan.get(
            "issues",
            []
        )


        security = scan.get(
            "security",
            []
        )


        todos = scan.get(
            "todos",
            []
        )



        # Documentation

        for issue in issues:

            if issue.get("type") == "documentation":

                score -= 15

                breakdown["documentation"] -= 40



        # Testing

        for issue in issues:

            if issue.get("type") == "quality":

                score -= 10

                breakdown["testing"] -= 30



        # Security

        if security:

            score -= len(security) * 10

            breakdown["security"] -= len(security) * 20



        # TODO quality

        if len(todos) > 10:

            score -= 5

            breakdown["code_quality"] -= 10



        score = max(
            score,
            0
        )



        return {

            "score":
                score,


            "grade":
                self.grade(
                    score
                ),


            "breakdown":
                breakdown,

        }



    def grade(
        self,
        score: int,
    ):


        if score >= 90:

            return "A"


        if score >= 75:

            return "B"


        if score >= 60:

            return "C"


        if score >= 40:

            return "D"


        return "F"  