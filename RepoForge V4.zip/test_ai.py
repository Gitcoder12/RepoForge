import os
import sys
from dotenv import load_dotenv

sys.path.insert(0, 'src')
from repoforge.providers.openrouter import OpenRouterProvider

load_dotenv()
api_key = os.getenv("OPENROUTER_API_KEY")

if not api_key or not api_key.startswith("sk-or-"):
    print("❌ Error: Invalid or missing OPENROUTER_API_KEY in .env file")
else:
    print("⏳ Calling OpenRouter (Free Model: google/gemma-2-9b-it:free)...")
    
    # Using a guaranteed free model on OpenRouter
    provider = OpenRouterProvider(api_key=api_key, model="google/gemma-2-9b-it:free")
    
    response = provider.generate(
        prompt="What is RepoForge in one sentence?",
        system_prompt="You are a helpful AI assistant."
    )
    
    print("\n✅ AI Response:")
    print("-" * 60)
    print(response)
    print("-" * 60)
    print("\n🎉 SUCCESS! RepoForge is officially connected to an AI provider.")
