"""
RepoForge V4 Improvement Selector

Picks the single best improvement to execute.
"""

from typing import List, Dict, Any, Optional


class ImprovementSelector:
    """
    Selects the top-ranked improvement.
    Returns None if no issues exist or the top score is too low.
    """

    def select(
        self,
        ranked_issues: List[Dict[str, Any]],
        min_score: float = 0.20  # Don't act on trivial improvements
    ) -> Optional[Dict[str, Any]]:
        """
        Returns the selected improvement dict, or None.
        """
        if not ranked_issues:
            return None

        top = ranked_issues[0]
        if top.get("value_score", 0.0) < min_score:
            return None  # Repo is healthy, skip V4 changes

        return top