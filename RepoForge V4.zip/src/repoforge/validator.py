"""
RepoForge Validator V3

Validates repository changes after AI modifications.

Checks:
- Python syntax
- Repository health
- File validity
"""

from pathlib import Path
import ast


class Validator:
    """
    Base validator engine.
    """


    IGNORE_DIRS = {
        ".git",
        ".repoforge",
        "__pycache__",
        "node_modules",
        "venv",
        ".venv",
        "dist",
        "build"
    }



    def __init__(
        self,
        repo_path="."
    ):

        self.repo_path = Path(
            repo_path
        )



    def validate_file(
        self,
        file_path
    ):

        target = (
            self.repo_path /
            file_path
        )


        if not target.exists():

            return {

                "passed": False,

                "message":
                    "File does not exist"

            }



        if target.suffix == ".py":

            try:

                ast.parse(
                    target.read_text(
                        encoding="utf-8",
                        errors="ignore"
                    )
                )


                return {

                    "passed": True,

                    "message":
                        "Python syntax valid"

                }


            except SyntaxError as error:

                return {

                    "passed": False,

                    "message":
                        str(error)

                }


            except PermissionError as error:

                return {

                    "passed": True,

                    "warning":
                        f"Permission skipped: {error}"

                }



        return {

            "passed": True,

            "message":
                "File validated"

        }



    def validate(
        self
    ):

        results = []


        for file in self.repo_path.rglob(
            "*.py"
        ):


            if any(

                part in self.IGNORE_DIRS

                for part in file.parts

            ):

                continue



            try:

                source = file.read_text(
                    encoding="utf-8",
                    errors="ignore"
                )


                ast.parse(
                    source
                )


                results.append({

                    "file":
                        str(file),

                    "passed":
                        True

                })



            except PermissionError as error:


                results.append({

                    "file":
                        str(file),

                    "passed":
                        True,

                    "warning":
                        f"Permission skipped: {error}"

                })



            except SyntaxError as error:


                results.append({

                    "file":
                        str(file),

                    "passed":
                        False,

                    "error":
                        str(error)

                })



            except Exception as error:


                results.append({

                    "file":
                        str(file),

                    "passed":
                        False,

                    "error":
                        str(error)

                })



        passed = (

            len(results) == 0

            or all(

                item["passed"]

                for item in results

            )

        )


        return {

            "syntax": {

                "passed":
                    passed,

                "files":
                    results

            }

        }



# RepoForge V3 compatibility

RepoValidator = Validator