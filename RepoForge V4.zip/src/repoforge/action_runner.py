"""
RepoForge Action Runner V3

Executes validated AI generated Forge actions.
"""


from pathlib import Path

from repoforge.action_parser import ActionParser
from repoforge.patch_engine import PatchEngine



class ActionRunner:


    def __init__(
        self,
        repo_path
    ):

        self.repo_path = Path(
            repo_path
        )

        self.parser = ActionParser()

        self.patch_engine = PatchEngine(
            repo_path
        )



    def run(
        self,
        response
    ):


        print(
            "🔍 Parsing AI actions..."
        )


        actions = self.parser.parse(
            response
        )


        print(
            f"🔨 Actions detected: {len(actions)}"
        )



        completed = []

        results = []



        for action in actions:


            result = self.execute(
                action
            )


            results.append(
                result
            )


            if result.get(
                "success",
                False
            ):

                completed.append(
                    action
                )



        return {


            "total_actions":

                len(actions),



            "completed":

                len(completed),



            "actions":

                completed,



            "results":

                results

        }



    def execute(
        self,
        action
    ):


        action_type = action.get(
            "type"
        )



        if action_type in [

            "create",

            "modify"

        ]:


            return self.patch_engine.apply_patch(

                action["file"],

                action["content"]

            )



        if action_type == "delete":


            target = (

                self.repo_path /

                action["file"]

            )



            if target.exists():

                target.unlink()



            return {


                "success":

                    True,



                "message":

                    "File deleted"

            }



        return {


            "success":

                False,



            "message":

                "Unknown action"

        }