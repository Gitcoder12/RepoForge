"""
RepoForge AI Models
"""

DEFAULT_MODEL = "auto"

MODELS = {

    # Auto
    "auto": "openrouter/auto",

    # OpenAI
    "gpt": "openai/gpt-5",
    "gpt-mini": "openai/gpt-5-mini",

    # Anthropic
    "claude": "anthropic/claude-sonnet-4",
    "opus": "anthropic/claude-opus-4",

    # Google
    "gemini": "google/gemini-2.5-pro",
    "flash": "google/gemini-2.5-flash",

    # DeepSeek
    "deepseek": "deepseek/deepseek-chat",
    "r1": "deepseek/deepseek-r1",

    # Meta
    "llama": "meta-llama/llama-3.3-70b-instruct",

    # Alibaba
    "qwen": "qwen/qwen3-235b-a22b",

    # Mistral
    "mistral": "mistralai/mistral-large",
    "codestral": "mistralai/codestral",

    # xAI
    "grok": "x-ai/grok-4",

    # Moonshot
    "kimi": "moonshotai/kimi-k2",

    # Zhipu
    "glm": "z-ai/glm-4.5",

    # Cohere
    "command": "cohere/command-a",

    # Cerebras
    "cerebras": "cerebras/cerebras-gpt",

    # Microsoft
    "phi": "microsoft/phi-4",

    # IBM
    "granite": "ibm/granite-3.3-8b-instruct",

    # Perplexity
    "sonar": "perplexity/sonar-pro",
}