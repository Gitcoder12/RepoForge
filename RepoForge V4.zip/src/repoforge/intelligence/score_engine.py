"""
RepoForge Score Engine V4

Weighted repository intelligence scoring.
"""


from typing import Dict, Any



class ScoreEngine:


    def calculate(
        self,
        scan: Dict[str, Any],
    ) -> Dict[str, Any]:


        if not isinstance(
            scan,
            dict
        ):
            scan = {}


        stats = scan.get(
            "statistics",
            {}
        )


        structure = scan.get(
            "structure",
            {}
        )


        issues = scan.get(
            "issues",
            []
        )


        security = scan.get(
            "security",
            []
        )


        todos = scan.get(
            "todos",
            []
        )


        files = stats.get(
            "files",
            0
        )


        lines = stats.get(
            "lines",
            0
        )


        documentation = 100

        testing = 100

        security_score = 100

        maintainability = 100



        # Documentation

        has_readme = False


        for item in structure:

            if "readme" in str(item).lower():

                has_readme = True

                break



        if not has_readme:

            documentation -= 30



        # Testing

        for issue in issues:

            if "test" in str(issue).lower():

                testing -= 30



        # Security

        security_score -= len(
            security
        ) * 10



        # Maintainability

        if files > 3000:

            maintainability -= 10


        if lines > 500000:

            maintainability -= 10


        if len(todos) > 20:

            maintainability -= 10



        breakdown = {


            "documentation":

                max(
                    documentation,
                    0
                ),


            "testing":

                max(
                    testing,
                    0
                ),


            "security":

                max(
                    security_score,
                    0
                ),


            "maintainability":

                max(
                    maintainability,
                    0
                )

        }



        score = int(

            (
                breakdown["documentation"] * 0.25
                +
                breakdown["testing"] * 0.25
                +
                breakdown["security"] * 0.25
                +
                breakdown["maintainability"] * 0.25
            )

        )



        return {

            "score": score,

            "grade": self.grade(
                score
            ),

            "breakdown": breakdown,

            "repository": {

                "files": files,

                "lines": lines

            }

        }



    def grade(
        self,
        score: int
    ):


        if score >= 90:

            return "A"


        if score >= 75:

            return "B"


        if score >= 60:

            return "C"


        if score >= 40:

            return "D"


        return "F"