"""
RepoForge AI Model Router

Selects the best AI model
for each engineering task.
"""


from typing import Dict, List



class AIRouter:
    """
    Routes tasks to suitable AI models.
    """


    def __init__(self):

        self.routes: Dict[str, Dict[str, List[str]]] = {


            # Software design

            "architecture": {

                "free": [
                    "deepseek",
                    "qwen",
                    "llama",
                ],

                "paid": [
                    "claude",
                    "gpt",
                    "gemini",
                ],

            },


            # Coding

            "coding": {

                "free": [
                    "deepseek",
                    "qwen",
                    "llama",
                ],

                "paid": [
                    "claude",
                    "gpt",
                ],

            },


            # Repository improvement

            "analysis": {

                "free": [
                    "deepseek",
                    "qwen",
                ],

                "paid": [
                    "claude",
                    "gpt",
                ],

            },


            "security": {

                "free": [
                    "deepseek",
                    "qwen",
                ],

                "paid": [
                    "claude",
                    "gpt",
                ],

            },


            "refactoring": {

                "free": [
                    "deepseek",
                    "qwen",
                ],

                "paid": [
                    "claude",
                    "codestral",
                ],

            },


            "testing": {

                "free": [
                    "deepseek",
                    "qwen",
                ],

                "paid": [
                    "claude",
                    "gpt",
                ],

            },


            "documentation": {

                "free": [
                    "qwen",
                    "deepseek",
                ],

                "paid": [
                    "gemini",
                    "claude",
                ],

            },


            "research": {

                "free": [
                    "deepseek",
                    "qwen",
                ],

                "paid": [
                    "gemini",
                    "claude",
                ],

            },


            "general": {

                "free": [
                    "qwen",
                    "deepseek",
                ],

                "paid": [
                    "gpt",
                    "claude",
                ],

            },

        }



    def choose(
        self,
        task: str,
    ):

        route = self.routes.get(
            task,
            self.routes["general"],
        )


        return {

            "task":
                task,

            "free":
                route["free"],

            "paid":
                route["paid"],

        }