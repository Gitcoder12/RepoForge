import os
import platform
import requests
from dotenv import load_dotenv


load_dotenv()


def check_key(name: str):
    value = os.getenv(name)
    if value and value.strip():
        return True, "Present"
    return False, "Missing"


def check_ollama():
    try:
        r = requests.get("http://localhost:11434/api/tags", timeout=2)
        if r.status_code == 200:
            return True, "Running"
        return False, f"HTTP {r.status_code}"
    except Exception:
        return False, "Not Running"


def check_internet():
    try:
        requests.get("https://www.google.com", timeout=3)
        return True, "Connected"
    except Exception:
        return False, "Offline"


def print_status(name, ok, msg):
    icon = "✅" if ok else "❌"
    print(f"{name:<22} {icon} {msg}")


def run_doctor():
    print("=" * 50)
    print("🩺 RepoForge Doctor")
    print("=" * 50)

    print_status(
        "Python",
        True,
        platform.python_version()
    )

    env_exists = os.path.exists(".env")
    print_status(
        ".env File",
        env_exists,
        "Found" if env_exists else "Missing"
    )

    print()

    providers = [
        "OPENAI_API_KEY",
        "ANTHROPIC_API_KEY",
        "GOOGLE_API_KEY",
        "DEEPSEEK_API_KEY",
        "ZHIPU_API_KEY",
        "OPENROUTER_API_KEY",
    ]

    healthy = 0

    for key in providers:
        ok, msg = check_key(key)
        if ok:
            healthy += 1
        print_status(key.replace("_API_KEY", ""), ok, msg)

    print()

    ok, msg = check_ollama()
    if ok:
        healthy += 1
    print_status("Ollama", ok, msg)

    ok, msg = check_internet()
    print_status("Internet", ok, msg)

    print()
    print("=" * 50)

    if healthy:
        print(f"🎉 Healthy providers found: {healthy}")
    else:
        print("⚠️ No working providers detected.")

    print("=" * 50)


if __name__ == "__main__":
    run_doctor()