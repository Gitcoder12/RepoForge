# test_fix.py
import os
from openai import OpenAI

# ==========================================
# PICK ONE: Uncomment the provider you want
# ==========================================

# --- OPTION 1: DEEPSEEK (cheap, fast, works) ---
API_KEY = "sk-7208e5dfa6f94e518baa2edbfe422403"
BASE_URL = "https://api.deepseek.com/v1"
MODEL = "deepseek-chat"

# --- OPTION 2: OPENROUTER (free models) ---
# API_KEY = "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"
# BASE_URL = "https://openrouter.ai/api/v1"
# MODEL = "meta-llama/llama-3.3-70b-instruct:free"   # <- THIS ONE EXISTS

# --- OPTION 3: OPENAI (your key looks valid) ---
# API_KEY = "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"
# BASE_URL = "https://api.openai.com/v1"
# MODEL = "gpt-4o-mini"

# ==========================================

client = OpenAI(api_key=API_KEY, base_url=BASE_URL)

try:
    response = client.chat.completions.create(
        model=MODEL,
        messages=[{"role": "user", "content": "Say 'Hello, RepoForge is working!'"}]
    )
    print("✅ SUCCESS:", response.choices[0].message.content)
except Exception as e:
    print("❌ FAILED:", e)