import typer


def run_providers():
    typer.echo("\n📦 Installed Providers")
    typer.echo("=" * 30)

    providers = [
        ("Mock", "Installed"),
        ("OpenAI", "Available"),
        ("Anthropic", "Available"),
        ("OpenRouter", "Available"),
        ("DeepSeek", "Available"),
        ("Ollama", "Available"),
        ("Gemini", "Available"),
    ]

    for name, status in providers:
        icon = "✅" if status == "Installed" else "⭕"
        typer.echo(f"{icon} {name:<15} {status}")