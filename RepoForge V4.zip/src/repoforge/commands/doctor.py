import os
import platform
from pathlib import Path

import requests
from dotenv import load_dotenv


load_dotenv()


def check_openai():
    key = os.getenv("OPENAI_API_KEY")
    if not key:
        return "⚪ No API Key"

    headers = {"Authorization": f"Bearer {key}"}

    try:
        r = requests.get(
            "https://api.openai.com/v1/models",
            headers=headers,
            timeout=10,
        )

        if r.status_code == 200:
            return "🟢 Connected"

        if r.status_code == 429:
            return "🔴 No Credits / Quota"

        return f"🔴 HTTP {r.status_code}"

    except Exception:
        return "🔴 Offline"


def check_openrouter():
    key = os.getenv("OPENROUTER_API_KEY")
    if not key:
        return "⚪ No API Key"

    headers = {"Authorization": f"Bearer {key}"}

    try:
        r = requests.get(
            "https://openrouter.ai/api/v1/models",
            headers=headers,
            timeout=10,
        )

        if r.status_code == 200:
            return "🟢 Connected"

        if r.status_code in (401, 402):
            return "🔴 Invalid Key / No Credits"

        return f"🔴 HTTP {r.status_code}"

    except Exception:
        return "🔴 Offline"


def check_deepseek():
    key = os.getenv("DEEPSEEK_API_KEY")
    if not key:
        return "⚪ No API Key"

    return "🟡 API Key Found"


def check_ollama():
    try:
        r = requests.get(
            "http://localhost:11434/api/tags",
            timeout=3,
        )

        if r.status_code == 200:
            return "🟢 Running"

        return "🔴 Not Running"

    except Exception:
        return "🔴 Not Running"


def run_doctor():
    print("\n🩺 RepoForge Doctor")
    print("=" * 50)

    print(f"OS        : {platform.system()} {platform.release()}")
    print(f"Python    : {platform.python_version()}")

    print("\nProviders")
    print("-" * 50)

    print(f"Mock       : 🟢 Ready")
    print(f"OpenAI     : {check_openai()}")
    print(f"OpenRouter : {check_openrouter()}")
    print(f"DeepSeek   : {check_deepseek()}")
    print(f"Ollama     : {check_ollama()}")

    print("\nConfiguration")
    print("-" * 50)

    env = Path(".env")

    if env.exists():
        print("🟢 .env Found")
    else:
        print("🔴 .env Missing")

    print("\nDoctor Complete ✓")