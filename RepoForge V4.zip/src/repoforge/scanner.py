"""
RepoForge Universal Scanner V3
"""

from pathlib import Path


class RepoScanner:


    LANGUAGE_MAP = {

        ".py": "Python",
        ".js": "JavaScript",
        ".jsx": "JavaScript",
        ".ts": "TypeScript",
        ".tsx": "TypeScript",

        ".java": "Java",

        ".cpp": "C++",
        ".c": "C",

        ".go": "Go",

        ".rs": "Rust",

        ".rb": "Ruby",

        ".php": "PHP",

        ".html": "HTML",

        ".css": "CSS",

        ".md": "Markdown",

        ".json": "JSON",

        ".yaml": "YAML",
        ".yml": "YAML",

        ".toml": "TOML"

    }


    IGNORE = {

        ".git",
        ".github",
        ".vscode",
        ".idea",
        "__pycache__",
        "node_modules",
        "dist",
        "build",
        ".repoforge"

    }


    def __init__(self, repo_path):

        self.repo_path = Path(
            repo_path
        ).resolve()



    def iter_files(self):

        if not self.repo_path.exists():

            return


        for file in self.repo_path.rglob("*"):


            if not file.is_file():

                continue


            if any(
                part in self.IGNORE
                for part in file.parts
            ):

                continue


            yield file



    def count_lines(self, file):

        try:

            return len(
                file.read_text(
                    encoding="utf-8",
                    errors="ignore"
                ).splitlines()
            )

        except:

            return 0



    def analyze(self):

        total_files = 0

        total_lines = 0

        languages = {}



        for file in self.iter_files():


            total_files += 1


            total_lines += self.count_lines(
                file
            )


            lang = self.LANGUAGE_MAP.get(
                file.suffix.lower()
            )


            if lang:

                languages[lang] = (

                    languages.get(
                        lang,
                        0
                    )
                    +
                    1

                )



        return {


            "statistics": {

                "files":
                    total_files,

                "lines":
                    total_lines

            },


            "languages":
                languages

        }