"""
RepoForge Workflow Engine V3 + V4 Decision Layer

Pipeline:

Scanner
   ↓
Intelligence Engine
   ↓
[V4 Issue Detector → Priority Engine → Improvement Selector]   ← V4 ADDED
   ↓
Difficulty Engine
   ↓
AI Strategist
   ↓
AI Orchestrator (receives selected_improvement)
   ↓
Action Runner
   ↓
Validator
   ↓
Git Checkpoint
   ↓
Reporter
"""


from typing import Dict, Any


from repoforge.validator import RepoValidator
from repoforge.git_manager import GitManager
from repoforge.orchestrator import AIOrchestrator
from repoforge.action_runner import ActionRunner
from repoforge.scanner import RepoScanner
from repoforge.strategist import AIStrategist
from repoforge.reporter import Reporter

from repoforge.intelligence.intelligence_engine import IntelligenceEngine

# V4 modules – imported inside execute() to avoid circular dependencies
# from repoforge.issue_detector import IssueDetector
# from repoforge.priority_engine import PriorityEngine
# from repoforge.improvement_selector import ImprovementSelector



class WorkflowEngine:


    def __init__(
        self,
        repo_path: str,
    ):

        self.repo_path = repo_path


        self.scanner = RepoScanner(
            repo_path
        )


        self.intelligence = IntelligenceEngine(
            repo_path
        )


        self.strategist = AIStrategist()


        self.ai = AIOrchestrator()


        self.runner = ActionRunner(
            repo_path
        )


        self.validator = RepoValidator(
            repo_path
        )


        self.git = GitManager(
            repo_path
        )


        self.reporter = Reporter(
            repo_path
        )



    def normalize_scan(
        self,
        scan
    ):

        if not isinstance(
            scan,
            dict
        ):

            return {

                "statistics": {
                    "files": 0,
                    "lines": 0
                },

                "languages": {}

            }


        return scan



    def normalize_intelligence(
        self,
        intelligence
    ):

        if not isinstance(
            intelligence,
            dict
        ):

            intelligence = {}


        if "quality_score" not in intelligence:


            quality = intelligence.get(
                "quality",
                {}
            )


            score = intelligence.get(
                "score",
                {}
            )


            intelligence["quality_score"] = {


                "score":

                    score.get(
                        "score",
                        quality.get(
                            "score",
                            0
                        )
                    ),


                "grade":

                    score.get(
                        "grade",
                        quality.get(
                            "grade",
                            "N/A"
                        )
                    )

            }


        return intelligence



    def calculate_difficulty(
        self,
        scan
    ):


        stats = scan.get(
            "statistics",
            {}
        )


        files = stats.get(
            "files",
            0
        )


        lines = stats.get(
            "lines",
            0
        )


        if files > 2000 or lines > 300000:

            return {

                "level": "Extreme",

                "reason":
                    "Large enterprise repository"

            }


        if files > 500 or lines > 100000:

            return {

                "level": "Hard",

                "reason":
                    "Large repository"

            }


        return {

            "level": "Normal",

            "reason":
                "Standard repository"

        }



    def execute(
        self,
        prompt: str,
    ) -> Dict[str, Any]:


        result = {

            "prompt": prompt,

            "stages": {}

        }



        # Scanner

        scan = self.normalize_scan(

            self.scanner.analyze()

        )


        result["stages"]["scan"] = scan



        # Intelligence

        intelligence = self.normalize_intelligence(

            self.intelligence.analyze(
                scan
            )

        )


        result["stages"]["intelligence"] = intelligence


        # ==================== V4 DECISION LAYER ====================
        from repoforge.issue_detector import IssueDetector
        from repoforge.priority_engine import PriorityEngine
        from repoforge.improvement_selector import ImprovementSelector

        detector = IssueDetector()
        raw_issues = detector.detect(scan, intelligence)

        priority = PriorityEngine()
        ranked_issues = priority.rank(raw_issues)

        selector = ImprovementSelector()
        selected_improvement = selector.select(ranked_issues)

        result["stages"]["v4_analysis"] = {
            "raw_issues": raw_issues,
            "ranked_issues": ranked_issues,
            "selected_improvement": selected_improvement
        }
        # ===========================================================


        # FIX: expose quality score globally

        result["quality_score"] = intelligence.get(

            "quality_score",

            {
                "score": 0,
                "grade": "N/A"
            }

        )



        # Difficulty

        difficulty = self.calculate_difficulty(
            scan
        )


        result["stages"]["difficulty"] = difficulty



        # Strategy

        plan = self.strategist.create_plan(

            prompt,

            context={

                "issues":
                    scan.get(
                        "issues",
                        []
                    ),

                "security":
                    scan.get(
                        "security",
                        []
                    )

            },

            difficulty=difficulty

        )


        result["stages"]["strategy"] = {

            "mode":
                plan.mode,

            "roles":
                plan.roles,

            "discussion_rounds":
                plan.discussion_rounds,

            "review":
                plan.review,

            "parallel":
                plan.parallel

        }



        # AI (now receives the selected improvement)

        ai_result = self.ai.execute(

            prompt,

            context={

                "scan": scan,

                "intelligence": intelligence,

                "difficulty": difficulty,

                "strategy":
                    result["stages"]["strategy"],

                "selected_improvement": selected_improvement   # <-- V4 addition

            }

        )


        result["stages"]["ai"] = ai_result



        if isinstance(
            ai_result,
            dict
        ):

            response = ai_result.get(
                "response",
                ""
            )

        else:

            response = str(
                ai_result
            )



        # Forge

        action_result = self.runner.run(
            response
        )


        result["stages"]["forge"] = action_result



        # Validation

        validation = self.validator.validate()


        result["stages"]["validation"] = validation



        completed_actions = 0


        if isinstance(
            action_result,
            dict
        ):

            completed_actions = action_result.get(
                "completed",
                0
            )



        syntax_ok = (

            validation.get(
                "syntax",
                {}
            ).get(
                "passed",
                False
            )

        )



        if completed_actions > 0 and syntax_ok:


            git_result = self.git.save_state(

                "RepoForge AI improvement"

            )


        elif completed_actions == 0:


            git_result = {

                "success": False,

                "message":
                    "No Forge actions completed. Git checkpoint skipped."

            }


        else:


            git_result = {

                "success": False,

                "message":
                    "Validation failed. Git checkpoint skipped."

            }



        result["stages"]["git"] = git_result



        # Reporter

        result["stages"]["report"] = self.reporter.generate(
            result
        )



        return result