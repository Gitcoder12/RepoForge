"""
RepoForge Provider Registry

Central registry of supported AI providers.
"""

DEFAULT_PROVIDER = "openrouter"

PROVIDERS = {

    # Multi-Provider Gateway
    "openrouter": {
        "name": "OpenRouter",
        "enabled": True,
    },

    # Native Providers
    "openai": {
        "name": "OpenAI",
        "enabled": False,
    },

    "anthropic": {
        "name": "Anthropic",
        "enabled": False,
    },

    "google": {
        "name": "Google Gemini",
        "enabled": False,
    },

    "deepseek": {
        "name": "DeepSeek",
        "enabled": False,
    },

    "ollama": {
        "name": "Ollama",
        "enabled": False,
    },

    "groq": {
        "name": "Groq",
        "enabled": False,
    },

    "cerebras": {
        "name": "Cerebras",
        "enabled": False,
    },

    "zhipu": {
        "name": "Zhipu AI",
        "enabled": False,
    },

    "mistral": {
        "name": "Mistral AI",
        "enabled": False,
    },

    "cohere": {
        "name": "Cohere",
        "enabled": False,
    },

    "together": {
        "name": "Together AI",
        "enabled": False,
    },

    "fireworks": {
        "name": "Fireworks AI",
        "enabled": False,
    },

    "nebius": {
        "name": "Nebius AI",
        "enabled": False,
    },

    "moonshot": {
        "name": "Moonshot AI",
        "enabled": False,
    },

    "perplexity": {
        "name": "Perplexity",
        "enabled": False,
    },

    "openai-compatible": {
        "name": "OpenAI Compatible",
        "enabled": False,
    },
}