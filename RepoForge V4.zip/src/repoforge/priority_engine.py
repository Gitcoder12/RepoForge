"""
RepoForge V4 Priority Engine

Calculates a value_score for each issue
to determine the most impactful change.
"""

from typing import List, Dict, Any


class PriorityEngine:
    """
    Ranks issues by ROI (Impact vs Effort).
    """

    def rank(self, issues: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """
        Sorts issues in descending order of value_score.
        Adds a 'value_score' and 'rationale' field to each dict.
        """
        if not issues:
            return []

        ranked = []
        for issue in issues:
            severity = issue.get("severity_score", 0.0)
            effort = issue.get("effort_estimate", 0.5)
            confidence = issue.get("confidence", 0.5)

            # Formula: 50% severity, 30% confidence, -20% effort
            value_score = (severity * 0.50) + (confidence * 0.30) - (effort * 0.20)
            issue["value_score"] = round(value_score, 4)

            # Generate human-readable rationale for the reporter
            rationale = (
                f"Priority {issue['type']} (Sev: {severity:.2f}, Effort: {effort:.2f}, Conf: {confidence:.2f}) "
                f"→ Score: {issue['value_score']:.3f}"
            )
            issue["rationale"] = rationale
            ranked.append(issue)

        # Sort descending by value_score
        ranked.sort(key=lambda x: x.get("value_score", 0.0), reverse=True)
        return ranked