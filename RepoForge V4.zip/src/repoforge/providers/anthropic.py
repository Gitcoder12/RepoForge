from typing import AsyncGenerator, Dict, Any
import repoforge.providers.anthropic as anthropic
from .base import BaseProvider
from .registry import ProviderRegistry

@ProviderRegistry.register
class AnthropicProvider(BaseProvider):
    """Anthropic Claude provider"""
    
    def _initialize(self):
        self.client = anthropic.Anthropic(api_key=self.api_key)
        self._models = self.config.get("models", ["claude-3-opus-20240229", "claude-3-sonnet-20240229"])
    
    def generate(self, prompt: str, system_prompt: str = "", **kwargs) -> str:
        model = kwargs.get("model", self._models[0])
        response = self.client.messages.create(
            model=model,
            max_tokens=4096,
            system=system_prompt,
            messages=[{"role": "user", "content": prompt}],
            **kwargs
        )
        return response.content[0].text
    
    async def stream(self, prompt: str, system_prompt: str = "", **kwargs) -> AsyncGenerator[str, None]:
        model = kwargs.get("model", self._models[0])
        with self.client.messages.stream(
            model=model,
            max_tokens=4096,
            system=system_prompt,
            messages=[{"role": "user", "content": prompt}],
            **kwargs
        ) as stream:
            for text in stream.text_stream:
                yield text
    
    def get_capabilities(self) -> Dict[str, Any]:
        return {
            "name": self.name,
            "models": self.models,
            "streaming": True,
            "max_tokens": 4096,
            "context_window": 200000
        }
    
    @property
    def name(self) -> str:
        return "anthropic"
    
    @property
    def models(self) -> list:
        return self._models