"""
RepoForge Provider Factory

Creates AI providers dynamically.

Providers are imported only when needed.
"""


import os
import importlib



class ProviderFactory:
    """
    Creates and configures AI providers.
    """


    PROVIDER_MAP = {

        "openai":
            "repoforge.providers.openai.OpenAIProvider",

        "gpt":
            "repoforge.providers.openai.OpenAIProvider",


        "anthropic":
            "repoforge.providers.anthropic.AnthropicProvider",

        "claude":
            "repoforge.providers.anthropic.AnthropicProvider",


        "openrouter":
            "repoforge.providers.openrouter.OpenRouterProvider",


        "ollama":
            "repoforge.providers.ollama.OllamaProvider",


        "mock":
            "repoforge.providers.mock.MockProvider",

    }


    def create(
        self,
        provider_name: str,
    ):

        provider_name = (
            provider_name
            .lower()
            .strip()
        )


        path = self.PROVIDER_MAP.get(
            provider_name
        )


        if not path:

            raise ValueError(
                f"Unknown provider: {provider_name}"
            )


        module_name, class_name = (
            path.rsplit(
                ".",
                1
            )
        )


        module = importlib.import_module(
            module_name
        )


        provider_class = getattr(
            module,
            class_name
        )


        api_key = self.get_api_key(
            provider_name
        )


        return provider_class(
            api_key=api_key
        )



    def get_api_key(
        self,
        provider_name: str,
    ):

        keys = {

            "openai":
                "OPENAI_API_KEY",

            "gpt":
                "OPENAI_API_KEY",

            "anthropic":
                "ANTHROPIC_API_KEY",

            "claude":
                "ANTHROPIC_API_KEY",

            "openrouter":
                "OPENROUTER_API_KEY",

        }


        env_name = keys.get(
            provider_name
        )


        if not env_name:

            return None


        return os.getenv(
            env_name
        )



    def available_providers(self):

        return list(
            self.PROVIDER_MAP.keys()
        )