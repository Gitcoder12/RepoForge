from typing import AsyncGenerator, Dict, Any

from openai import OpenAI

from .base import BaseProvider
from .registry import ProviderRegistry

@ProviderRegistry.register
class OpenAIProvider(BaseProvider):
    """OpenAI GPT provider"""
    
    def _initialize(self):
        self.client = OpenAI(api_key=self.api_key)
        self._models = self.config.get("models", ["gpt-4", "gpt-3.5-turbo"])
    
    def generate(self, prompt: str, system_prompt: str = "", **kwargs) -> str:
        messages = []
        if system_prompt:
            messages.append({"role": "system", "content": system_prompt})
        messages.append({"role": "user", "content": prompt})
        
        model = kwargs.get("model", self._models[0])
        response = self.client.chat.completions.create(
            model=model,
            messages=messages,
            **kwargs
        )
        return response.choices[0].message.content
    
    async def stream(self, prompt: str, system_prompt: str = "", **kwargs) -> AsyncGenerator[str, None]:
        messages = []
        if system_prompt:
            messages.append({"role": "system", "content": system_prompt})
        messages.append({"role": "user", "content": prompt})
        
        model = kwargs.get("model", self._models[0])
        stream = self.client.chat.completions.create(
            model=model,
            messages=messages,
            stream=True,
            **kwargs
        )
        
        for chunk in stream:
            if chunk.choices[0].delta.content:
                yield chunk.choices[0].delta.content
    
    def get_capabilities(self) -> Dict[str, Any]:
        return {
            "name": self.name,
            "models": self.models,
            "streaming": True,
            "max_tokens": 4096,
            "context_window": 8192
        }
    
    @property
    def name(self) -> str:
        return "openai"
    
    @property
    def models(self) -> list:
        return self._models