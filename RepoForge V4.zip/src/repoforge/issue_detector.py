"""
RepoForge V4 Issue Detector

Converts existing intelligence breakdown scores into
structured, actionable improvement issues.
"""

from typing import Dict, Any, List, Optional
from dataclasses import dataclass, asdict
import logging

logger = logging.getLogger(__name__)


@dataclass
class Issue:
    """Standardized issue model for V4 Priority Engine."""
    type: str  # 'testing', 'security', 'maintainability', 'documentation'
    description: str
    recommendation: str  # Specific actionable step for the Strategist
    severity_score: float  # 0.0 (cosmetic) to 1.0 (critical)
    effort_estimate: float  # 0.0 (trivial) to 1.0 (massive refactor)
    confidence: float  # 0.0 to 1.0 (how sure we are this issue exists)
    location: Optional[str] = None
    metadata: Optional[Dict[str, Any]] = None


class IssueDetector:
    """
    Reads the quality_score breakdown from IntelligenceEngine
    and generates V4-compliant issues.
    """

    # Thresholds based on your ScoreEngine grading (A=90, B=75, C=60, D=40)
    THRESHOLDS = {
        "testing": 75,
        "security": 80,
        "maintainability": 75,
        "documentation": 70,
    }

    def detect(
        self,
        scan: Dict[str, Any],  # Kept for signature compatibility
        intelligence: Dict[str, Any],
    ) -> List[Dict[str, Any]]:
        """
        Main entry point. Returns List[Dict] for backward compatibility.
        """
        issues: List[Issue] = []

        # Extract the breakdown from your actual intelligence structure
        quality_score = intelligence.get("quality_score", {})
        breakdown = quality_score.get("breakdown", {})

        # If breakdown is empty, log and return empty (don't fake issues)
        if not breakdown:
            logger.info("No quality breakdown found. Skipping issue detection.")
            return []

        # ---- 1. Testing Gap ----
        test_score = breakdown.get("testing", 100)
        if test_score < self.THRESHOLDS["testing"]:
            issues.append(Issue(
                type="testing",
                description=f"Testing quality is low (score: {test_score})",
                recommendation="Add unit tests for core modules and integration tests for critical paths.",
                severity_score=0.85,
                effort_estimate=0.6,
                confidence=0.9,
                location="tests/",
                metadata={"current_score": test_score}
            ))

        # ---- 2. Security Risk (Highest Weight) ----
        sec_score = breakdown.get("security", 100)
        if sec_score < self.THRESHOLDS["security"]:
            issues.append(Issue(
                type="security",
                description=f"Security posture is weak (score: {sec_score})",
                recommendation="Audit input validation, add rate-limiting, check for dependency CVEs.",
                severity_score=1.0,  # MAX
                effort_estimate=0.7,
                confidence=0.85,
                location="repository",
                metadata={"current_score": sec_score}
            ))

        # ---- 3. Maintainability / Complexity ----
        maint_score = breakdown.get("maintainability", 100)
        if maint_score < self.THRESHOLDS["maintainability"]:
            issues.append(Issue(
                type="maintainability",
                description=f"Code complexity needs attention (score: {maint_score})",
                recommendation="Refactor complex functions, reduce cyclomatic complexity, add type hints.",
                severity_score=0.65,
                effort_estimate=0.8,
                confidence=0.8,
                location="source",
                metadata={"current_score": maint_score}
            ))

        # ---- 4. Documentation Gap (Lowest Priority) ----
        doc_score = breakdown.get("documentation", 100)
        if doc_score < self.THRESHOLDS["documentation"]:
            issues.append(Issue(
                type="documentation",
                description=f"Documentation is lacking (score: {doc_score})",
                recommendation="Create/update README, add API docs, and include inline docstrings.",
                severity_score=0.4,
                effort_estimate=0.3,
                confidence=0.95,
                location="README.md",
                metadata={"current_score": doc_score}
            ))

        # Convert to dict for pipeline compatibility
        return [asdict(issue) for issue in issues]