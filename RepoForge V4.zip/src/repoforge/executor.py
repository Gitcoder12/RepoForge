"""
RepoForge AI Executor V3

Executes AI tasks safely and returns
machine-readable Forge actions.
"""


from concurrent.futures import (
    ThreadPoolExecutor,
    as_completed,
)

import traceback


from repoforge.models import (
    DEFAULT_MODEL,
    MODELS,
)

from repoforge.providers.factory import ProviderFactory
from repoforge.providers.spare import SpareModel



class AIExecutor:


    def __init__(self):

        self.factory = ProviderFactory()

        self.spare_model = SpareModel()



    def _build_prompt(
        self,
        prompt: str,
        context: dict,
    ) -> str:


        return f"""
You are RepoForge AI Engineer.

Your job is to improve a software repository.

Repository Context:

{context}


Task:

{prompt}


STRICT OUTPUT RULES:

Your entire response MUST be ONLY a valid JSON array.

DO NOT output:

- analysis
- explanations
- headings
- markdown
- code fences
- comments


Required format:

[
  {{
    "type": "modify",
    "file": "relative/path/file.py",
    "content": "complete file content"
  }}
]


Rules:

1. JSON must pass Python json.loads().
2. Escape newlines inside strings using \\n.
3. Do not put real line breaks inside content strings.
4. Use relative paths only.
5. Never use absolute paths.
6. Preserve existing functionality.
7. Return complete file content.
8. Only modify files that need improvement.
9. If no safe improvement exists return:

[]


Return ONLY JSON.
"""



    def _execute_task(
        self,
        job: dict,
    ):


        task_name = job.get(
            "task",
            "unknown",
        )


        provider_name = job.get(
            "provider",
            "openrouter",
        )


        model_name = job.get(
            "model",
            DEFAULT_MODEL,
        )


        prompt = job.get(
            "prompt",
            "",
        )


        context = job.get(
            "context",
            {},
        )


        try:


            provider = self.factory.create(
                provider_name
            )


            model_id = MODELS.get(
                model_name,
                MODELS[DEFAULT_MODEL],
            )


            response = provider.generate(

                self._build_prompt(
                    prompt,
                    context,
                ),

                model=model_id,

            )


            return {

                "task":
                    task_name,


                "provider":
                    provider_name,


                "model":
                    model_name,


                "success":
                    True,


                "response":
                    response,

            }



        except Exception as error:


            try:


                response = self.spare_model.generate(

                    self._build_prompt(
                        prompt,
                        context,
                    )

                )


                return {

                    "task":
                        task_name,


                    "provider":
                        "spare_model",


                    "model":
                        "spare",


                    "success":
                        True,


                    "response":
                        response,


                    "fallback_reason":
                        str(error),

                }



            except Exception:


                return {

                    "task":
                        task_name,


                    "provider":
                        "none",


                    "model":
                        "failed",


                    "success":
                        False,


                    "response":
                        "[]",


                    "traceback":
                        traceback.format_exc(),

                }



    def execute(
        self,
        jobs,
    ):


        if not jobs:

            return []



        results = []


        workers = min(
            len(jobs),
            5,
        )


        with ThreadPoolExecutor(
            max_workers=workers
        ) as executor:


            futures = [

                executor.submit(
                    self._execute_task,
                    job,
                )

                for job in jobs

            ]


            for future in as_completed(
                futures
            ):

                results.append(
                    future.result()
                )


        return results