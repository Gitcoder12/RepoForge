"""
RepoForge Display V4

Autonomous AI Repository Engineer dashboard.
"""


from rich.console import Console
from rich.panel import Panel
from rich.table import Table



console = Console()



class Display:


    @staticmethod
    def header():

        console.print(
            Panel(
                "🔥 RepoForge V4\n"
                "Autonomous AI Repository Engineer",
                expand=False
            )
        )



    @staticmethod
    def forge_result(
        result
    ):


        Display.header()


        console.print(
            "\n🎯 Task"
        )


        console.print(
            result.get(
                "prompt",
                ""
            )
        )



        stages = result.get(
            "stages",
            {}
        )



        # =========================
        # Repository Analysis
        # =========================


        scan = stages.get(
            "scan",
            {}
        )


        table = Table(
            title="🔍 Repository Analysis"
        )


        table.add_column(
            "Metric"
        )


        table.add_column(
            "Value"
        )


        stats = scan.get(
            "statistics",
            {}
        )


        table.add_row(
            "Files",
            str(
                stats.get(
                    "files",
                    0
                )
            )
        )


        table.add_row(
            "Lines",
            str(
                stats.get(
                    "lines",
                    0
                )
            )
        )


        languages = scan.get(
            "languages",
            {}
        )


        if isinstance(
            languages,
            dict
        ):

            language_text = ", ".join(
                languages.keys()
            )

        elif isinstance(
            languages,
            list
        ):

            language_text = ", ".join(
                languages
            )

        else:

            language_text = str(
                languages
            )


        table.add_row(
            "Languages",
            language_text
        )


        console.print(
            table
        )



        # =========================
        # Intelligence
        # =========================


        intelligence = stages.get(
            "intelligence",
            {}
        )


        quality = intelligence.get(
            "quality_score",
            {}
        )


        console.print(
            "\n🧠 Intelligence"
        )


        if isinstance(
            quality,
            dict
        ):


            console.print(

                f"Quality Score: "
                f"{quality.get('score', 0)}/100\n"

                f"Grade: "
                f"{quality.get('grade', 'N/A')}"

            )


            breakdown = quality.get(
                "breakdown",
                {}
            )


            if breakdown:

                console.print(
                    "\nBreakdown:"
                )


                for key, value in breakdown.items():

                    console.print(
                        f"  {key.title()}: {value}%"
                    )


        else:


            console.print(
                f"Quality Score: {quality}/100"
            )



        # =========================
        # V4 Improvement Intelligence
        # =========================

        v4_analysis = stages.get("v4_analysis", {})

        if v4_analysis:
            console.print("\n🧠 V4 Improvement Intelligence")

            raw_issues = v4_analysis.get("raw_issues", [])
            ranked_issues = v4_analysis.get("ranked_issues", [])
            selected = v4_analysis.get("selected_improvement")

            console.print(f"   Issues Detected: {len(raw_issues)}")

            if ranked_issues:
                console.print("   Top Improvements:")
                for i, issue in enumerate(ranked_issues[:3], 1):
                    value_score = issue.get("value_score", 0)
                    console.print(
                        f"     {i}. {issue.get('type')} "
                        f"(score: {value_score:.3f})"
                    )

            if selected:
                console.print(f"   ✅ Selected: {selected.get('type')}")
                rationale = selected.get("rationale", "")
                if rationale:
                    console.print(f"      Rationale: {rationale}")
            else:
                console.print("   ℹ️  No improvement selected (repository healthy or scores too low)")



        # =========================
        # Recommendations
        # =========================


        recommendations = intelligence.get(
            "recommendations",
            []
        )


        if recommendations:


            console.print(
                "\n💡 Recommendations"
            )


            for item in recommendations[:5]:


                if isinstance(
                    item,
                    dict
                ):

                    console.print(
                        f"- {item.get('title','')}"
                    )

                else:

                    console.print(
                        f"- {item}"
                    )



        # =========================
        # Forge Actions
        # =========================


        forge = stages.get(
            "forge",
            {}
        )


        console.print(
            "\n🔨 Forge Actions"
        )


        forge_table = Table()


        forge_table.add_column(
            "Metric"
        )


        forge_table.add_column(
            "Value"
        )


        if isinstance(
            forge,
            dict
        ):


            total_actions = forge.get(
                "total_actions",
                forge.get(
                    "detected",
                    0
                )
            )


            completed = forge.get(
                "completed",
                0
            )


        elif isinstance(
            forge,
            list
        ):


            total_actions = len(
                forge
            )


            completed = 0


            for action in forge:


                if isinstance(
                    action,
                    dict
                ):


                    status = action.get(
                        "status",
                        action.get(
                            "success",
                            False
                        )
                    )


                    if status in [
                        "completed",
                        "success",
                        "done",
                        True
                    ]:

                        completed += 1


        else:


            total_actions = 0

            completed = 0



        forge_table.add_row(
            "Detected",
            str(
                total_actions
            )
        )


        forge_table.add_row(
            "Completed",
            str(
                completed
            )
        )


        console.print(
            forge_table
        )



        # =========================
        # Validation
        # =========================


        validation = stages.get(
            "validation",
            {}
        )


        syntax = validation.get(
            "syntax",
            {}
        )


        console.print(
            "\n🛡 Safety"
        )


        console.print(
            f"Validation: "
            f"{'✅' if syntax.get('passed', False) else '❌'}"
        )



        # =========================
        # Git
        # =========================


        git = stages.get(
            "git",
            {}
        )


        console.print(
            "\n📦 Git"
        )


        if isinstance(
            git,
            dict
        ):


            console.print(
                git.get(
                    "message",
                    "Checkpoint complete"
                )
            )


        else:


            console.print(
                "Checkpoint complete"
            )



        console.print(
            "\n🚀 RepoForge V4 finished"
        )