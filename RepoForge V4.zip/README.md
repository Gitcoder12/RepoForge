# RepoForge

> **Few-prompt AI repo automation — turn ideas into real files.**

You describe the idea once. RepoForge scaffolds, generates code, and writes docs with **progress bars + run stats** so you can review every phase.

This is the **autopilot**.  
**[AutoOpera](https://github.com/Gitcoder12/AutoOpera)** is the **manager** (routes models by strength). Together: ideas → multi-model execution → repositories.

---

## Manager + employees (how it fits)

| Piece | Role |
|-------|------|
| **You** | Ideas, goals, review |
| **RepoForge** | Few-prompt automation playbooks (scaffold / gen / docs / idea) |
| **AI providers** | Employees (DeepSeek, Groq, OpenRouter, …) |
| **AutoOpera** | Optional orchestration brain for complex multi-step AI work |

RepoForge uses strength-based routing itself (code / plan / docs / …). Same `.env` key style as AutoOpera.

---

## Quick start

```powershell
cd RepoForge
python -m pip install -r requirements.txt
$env:PYTHONPATH = "src"

# Offline — mock employee, full progress bars
python -m repoforge status
python -m repoforge scaffold my-tool --idea "JSON notes CLI"
python -m repoforge idea "CLI todo app with JSON storage" --name todo-cli --dest .

# With keys: copy .env.example → .env
copy .env.example .env
# then paste keys and re-run idea / gen / docs
```

---

## CLI (few prompts)

| Command | What you type | What happens |
|---------|----------------|--------------|
| `status` | — | Providers + who handles code/plan/docs |
| `scaffold NAME` | `--idea "..."` `--stack python\|fastapi` | Creates folders, main, tests, README, LICENSE |
| `analyze [path]` | — | Tree scan + AI completeness notes |
| `docs [path]` | `--overwrite` | AI README from tree |
| `gen "task"` | `--path folder` | Plan → code → write files |
| `idea "raw idea"` | `--name` `--stack` | **Flagship**: scaffold + AI implement + docs |

### Stats you’ll see

```text
▶ RepoForge — idea → reality: todo-cli
  [------------------------]   0%  [1/4] Scaffold project...
           ↳ wrote main.py (312 bytes)
  [######------------------]  25%  ✓ Scaffold project
  ...
════════════════════════════════════════
  REPOFORGE RUN STATS
  Duration      : 2.10s
  Phases        : 4 ok / 0 fail / 4 total
  Files written : 8
  Bytes written : 4,120
  AI calls      : 3
  Providers     :
    • mock             x3
════════════════════════════════════════
```

---

## Playbooks

1. **Scaffold** — deterministic templates (always works offline)  
2. **Gen** — AI plan + code fences → real files  
3. **Docs** — tree → README  
4. **Idea** — end-to-end idea → project (your flagship path)

---

## Layout

```text
RepoForge/
├── src/repoforge/
│   ├── forge.py       # playbooks
│   ├── ai.py          # strength routing + providers
│   ├── progress.py    # bars + stats
│   ├── templates.py   # zero-prompt scaffolding
│   ├── fsutil.py      # safe writes + fence parsing
│   └── cli.py
├── tests/
├── .env.example
└── requirements.txt
```

---

## Env

See `.env.example`. No keys → mock mode (still full progress/stats).  
Drop in DeepSeek / Groq / OpenRouter / etc. when you want live generation.

---

## License

MIT © DHARAVATH SATVIK
