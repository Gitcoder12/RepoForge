from repoforge.action_parser import ActionParser


response = """
```json
[
 {
  "type":"modify",
  "file":"README.md",
  "content":"hello"
 }
]